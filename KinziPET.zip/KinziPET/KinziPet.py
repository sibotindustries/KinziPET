import os
import ctypes
import subprocess
import time
import random
import psutil
import webbrowser
import platform
import tkinter as tk
from threading import Thread
from PIL import Image, ImageTk
import speech_recognition as sr
import pyttsx3

class KinziPet:
    def __init__(self):
        self.nome = "Kinzi"
        self.energia = 100
        self.humor = 100
        self.acesso_admin = self.verificar_acesso_admin()

        # Configuração inicial da interface gráfica
        self.root = tk.Tk()
        self.root.title("KinziPET")
        self.root.geometry("100x100")
        self.root.overrideredirect(True)  # Remove barra de título
        self.root.attributes("-topmost", True)  # Sempre no topo

        # Configuração de fala
        self.fala_engine = pyttsx3.init()
        self.fala_engine.setProperty('rate', 150)  # Ajusta a velocidade

        # Caminho das imagens e gifs do mascote
        self.impath = 'C:\\Users\\Administrador\\Desktop\\KinziPET\\image\\'
        self.x = random.randint(100, 500)
        self.y = random.randint(100, 300)
        self.cycle = 0
        self.check = 0
        self.event_number = random.randrange(1, 3, 1)

        # Carregando GIFs de animação
        self.idle = [tk.PhotoImage(file=self.impath+'idle.gif', format='gif -index %i' % i) for i in range(5)]
        self.idle_to_sleep = [tk.PhotoImage(file=self.impath+'idle_to_sleep.gif', format='gif -index %i' % i) for i in range(8)]
        self.sleep = [tk.PhotoImage(file=self.impath+'sleep.gif', format='gif -index %i' % i) for i in range(3)]
        self.sleep_to_idle = [tk.PhotoImage(file=self.impath+'sleep_to_idle.gif', format='gif -index %i' % i) for i in range(8)]
        self.walk_positive = [tk.PhotoImage(file=self.impath+'walking_positive.gif', format='gif -index %i' % i) for i in range(8)]
        self.walk_negative = [tk.PhotoImage(file=self.impath+'walking_negative.gif', format='gif -index %i' % i) for i in range(8)]

        # Configuração do rótulo de exibição
        self.label = tk.Label(self.root, bd=0, bg='black')
        self.label.pack()

        self.root.config(highlightbackground='black')
        self.root.wm_attributes('-transparentcolor', 'black')

        self.thread_interacao = Thread(target=self.terminal_interacao)
        self.thread_interacao.start()

        self.root.after(1, self.update)
        self.root.mainloop()

    def falar(self, mensagem):
        print(f"{self.nome}: {mensagem}")
        self.fala_engine.say(mensagem)
        self.fala_engine.runAndWait()

    def ouvir_comando(self):
        reconhecedor = sr.Recognizer()
        with sr.Microphone() as source:
            self.falar("Estou ouvindo...")
            try:
                audio = reconhecedor.listen(source, timeout=5)
                comando = reconhecedor.recognize_google(audio, language='pt-BR')
                return comando.lower()
            except sr.UnknownValueError:
                self.falar("Desculpe, não entendi.")
            except sr.RequestError:
                self.falar("Erro ao se conectar ao serviço de reconhecimento de fala.")
            except sr.WaitTimeoutError:
                self.falar("Você não disse nada.")
        return ""

    def verificar_acesso_admin(self):
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            return False

    def mover(self):
        self.x += random.choice([-3, 3])
        self.y += random.choice([-3, 3])
        self.x = max(0, min(self.root.winfo_screenwidth() - 100, self.x))
        self.y = max(0, min(self.root.winfo_screenheight() - 100, self.y))
        self.root.geometry(f'100x100+{self.x}+{self.y}')

    def gif_work(self, cycle, frames, first_num, last_num):
        if cycle < len(frames) - 1:
            cycle += 1
        else:
            cycle = 0
            self.event_number = random.randrange(first_num, last_num + 1, 1)
        return cycle

    def update(self):
        frame = self.idle[self.cycle]  # Padrão inicial é "idle"
        
        if self.check == 0:  # idle
            frame = self.idle[self.cycle]
            self.cycle = self.gif_work(self.cycle, self.idle, 1, 9)
        elif self.check == 1:  # idle to sleep
            frame = self.idle_to_sleep[self.cycle]
            self.cycle = self.gif_work(self.cycle, self.idle_to_sleep, 10, 10)
        elif self.check == 2:  # sleep
            frame = self.sleep[self.cycle]
            self.cycle = self.gif_work(self.cycle, self.sleep, 10, 15)
        elif self.check == 3:  # sleep to idle
            frame = self.sleep_to_idle[self.cycle]
            self.cycle = self.gif_work(self.cycle, self.sleep_to_idle, 1, 1)
        elif self.check == 4:  # walk towards left
            frame = self.walk_positive[self.cycle]
            self.cycle = self.gif_work(self.cycle, self.walk_positive, 1, 9)
            self.x -= 3
        elif self.check == 5:  # walk towards right
            frame = self.walk_negative[self.cycle]
            self.cycle = self.gif_work(self.cycle, self.walk_negative, 1, 9)
            self.x += 3

        self.label.configure(image=frame)
        self.mover()
        self.root.after(100, self.update)

    def monitorar_sistema(self):
        info = (
            f"Monitorando o sistema:\n"
            f"CPU: {psutil.cpu_percent()}%\n"
            f"Memória RAM: {psutil.virtual_memory().percent}%\n"
            f"Disco: {psutil.disk_usage('/').percent}%\n"
            f"Sistema operacional: {platform.system()} {platform.release()}"
        )
        self.falar(info)

    def alimentar_kinzi(self):
        self.falar("Uau, isso me deu energia!")
        self.energia += 20
        if self.energia > 100:
            self.energia = 100

    def mostrar_estatisticas(self):
        estatisticas = (
            f"Aqui estão minhas estatísticas:\n"
            f"Energia: {self.energia}\n"
            f"Humor: {self.humor}\n"
            f"Acesso Administrativo: {self.acesso_admin}"
        )
        self.falar(estatisticas)

    def terminal_interacao(self):
        while True:
            self.falar("O que você gostaria de fazer? Diga uma opção como 'conhecer', 'monitorar', 'brincar', 'descansar', 'alimentar', 'estatísticas' ou 'sair'.")
            comando = self.ouvir_comando()

            if "conhecer" in comando:
                self.falar("Prazer em conhecê-lo! Estou aqui para ajudar.")
            elif "monitorar" in comando:
                self.monitorar_sistema()
            elif "brincar" in comando:
                self.falar("Vamos brincar!")
                self.humor += 20
            elif "descansar" in comando:
                self.falar("Vou descansar um pouco.")
                self.energia += 30
            elif "alimentar" in comando:
                self.alimentar_kinzi()
            elif "estatísticas" in comando:
                self.mostrar_estatisticas()
            elif "sair" in comando:
                self.falar("Até mais!")
                self.root.destroy()
                break
            else:
                self.falar("Desculpe, não entendi. Tente novamente.")

if __name__ == "__main__":
    kinzi = KinziPet()